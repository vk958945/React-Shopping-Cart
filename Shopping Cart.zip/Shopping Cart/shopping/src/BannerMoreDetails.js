import { useEffect, useState } from "react"

function BannerMoreDetails() {

    const[banner,setBanner] =useState([])

    useEffect(() => {
      fetch('/api/bannermoredetail').then((res) => { return res.json() }).then((data) => {
        console.log(data)
        setBanner(data)
      })
  
    }, [])

    return ( 
       <section id="bannermore">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <h2 style={{textAlign:'center', marginTop:'40px', marginBottom:'40px'}}>{banner.bname}</h2>
                    <p>{banner.blongdesc}</p>
                </div>
            </div>
        </div>
       </section>
     );
}

export default BannerMoreDetails;