function About() {
    return ( 
        <h2 style={{textAlign:'center', margin:'100px'}}>
            Welcome To About Page.
        </h2>
     );
}

export default About;