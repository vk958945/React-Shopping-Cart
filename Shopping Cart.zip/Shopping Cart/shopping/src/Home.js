import Banner from './Banner'
import Productfetchhome from './Productfetchhome';
import Testi from './Testi'

function Home() {
    return ( 
        <>
        <Banner/>
        <Productfetchhome/>
        <Testi/>
        </>
     );
}

export default Home;