import { useContext, useEffect, useState } from "react";
import { LoginContext } from "./LoginContext";

function Cart() {    
    const { cart, setCart} = useContext(LoginContext)
    const [products, setProducts] = useState([])

    let totalamount = 0

    useEffect(() => {
        if(!cart.items){
            return
        }
        fetch('/api/allcartshow', {
            method: 'POST',
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ ids: Object.keys(cart.items) })
        }).then((res) => { return res.json() }).then((data) => {
            console.log(data)
            setProducts(data)
        })
    }, [cart.items])

    function handlequantity(id){
        let quantity= cart.items[id]
        return quantity

      }

      function handleprice(id,price){
          let tprice=handlequantity(id)*price
          totalamount =totalamount+tprice
        return  tprice

      }

      function handleincrement(e,id){
          let current_qnty=handlequantity(id)
          let _cart={...cart}
          if (current_qnty<10){

          _cart.items[id]=current_qnty+1
          _cart.totalitems +=1
          setCart(_cart)

          }
      }

      function handledecrement(e,id){
          let current_qnty=handlequantity(id)
          let _cart={...cart}
          if (current_qnty>1){

          _cart.items[id]=current_qnty-1
          _cart.totalitems -=1
          setCart(_cart)
          }
      }
      function handledelete(e,id){
        let current_qnty=handlequantity(id)
        let _cart={...cart}
       delete _cart.items[id]
        _cart.totalitems -= current_qnty
        setCart(_cart)

    }


    return ( 
        <section>
            <div className="container">
                <div className="row">
                    <div className="col-md-12">
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Product Name</th>
                                    <th>Product Description</th>
                                    <th>Quentity</th>
                                    <th>Price</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            
                            {products.map((result,key)=>(
                            <tr>
                            <td>{key+1}</td>
                            <td>{result.pname}</td>
                            <td>{result.pdesc}</td>
                            <td><button className="btn btn-danger" onClick={(e)=>{handledecrement(e,result._id)}}>-</button>{handlequantity(result._id)}<button className="btn btn-success" onClick={(e)=>{handleincrement(e,result._id)}}>+</button></td>
                            <td>{handleprice(result._id,result.pprice)}</td>
                            <td><button className="btn btn-danger" onClick={(e)=>{handledelete(e,result._id)}}>Delete</button></td>
                        </tr>
                        ))}
                        <tr><td colSpan="6">Total Amount: {totalamount}</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
     );
}

export default Cart;