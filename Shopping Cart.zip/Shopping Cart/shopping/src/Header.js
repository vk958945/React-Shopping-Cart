import { useContext } from "react";
import { Link, useNavigate } from "react-router-dom";
import { LoginContext } from "./LoginContext";
import img from "./logo.png"

function Header() {
  const{loginname,setLoginname,loginstatus,setLoginStatus, cart} = useContext(LoginContext)
  const navigate = useNavigate()
  function handlelogout(e){
    localStorage.setItem('loginname','')
    setLoginname(localStorage.getItem('loginname'))
    localStorage.removeItem('loginstatus')
    setLoginStatus(localStorage.getItem('loginstatus'))
    
    navigate('/login')
  }
  return ( 
    <section id="header">
    <div className="container">
      <div className="row">
        <div className="col-md-12">
          <nav className="navbar navbar-expand-lg">
            <div className="container-fluid">
              <Link className="navbar-brand" to="/"><img src={img} alt=""/></Link>
              <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="/navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false"
                aria-label="Toggle navigation">
                <i className="bi bi-list"></i>
              </button>
              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav ms-auto">
                
                  
                  {loginstatus?
                  <>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/">Home</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/about">About</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/testiformshow">Testimonial</Link>
                  </li>
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/">Gallery</Link>
                  </li>
                 
                  <li className="nav-item">
                    <Link className="nav-link active" aria-current="page" to="/">Welcome {loginname}</Link>
                  </li>

                  <Link to='/cart'> <i className="bi bi-cart4 me-2" style={{color:'blue', fontSize:'25px'}}>{cart.totalitems ? cart.totalitems : 0}</i></Link>

                  <li className="nav-item">
                    <button onClick={(e)=>{handlelogout(e)}} className="btn btn-danger">Logout</button>
                  </li>
                  </>
                  :
                  <>
                  <Link to='/cart'> <i className="bi bi-cart4 me-2" style={{color:'blue', fontSize:'25px'}}>{cart.totalitems ?  cart.totalitems : 0}</i></Link>
                  <li className="nav-item">
                  <Link className="nav-link active" aria-current="page" to="/login">Login</Link>
                </li>
                </>
                  }
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>

  </section>
   );
}

export default Header;