import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import img from "./sliderimg.png"

function ProductMoreDetail() {
    const { id } = useParams()
    const [ product, setProduct ] = useState([])
    useEffect(() => {
        fetch(`/api/singleproductfetch/${id}`).then((res) => { return res.json() }).then((data) => {
            console.log(data)
            setProduct(data)
        })
    }, [id])

    return (
        <section>
            <div className="container mt-5 mb-5">
                <div className="row">
                    <div className="col-md-3">
                        <img src={img} className="card-img-top img-fluid" alt="..." />

                    </div>
                    <div className="col-md-9">
                        <table className="table table:hover">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Description</th>
                                    <th>Product Price</th>
                                </tr>
                            </thead>

                            <tbody>
                                <tr>
                                    <td>{product.pname}</td>
                                    <td>{product.pdesc}</td>
                                    <td>{product.pprice}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default ProductMoreDetail;