import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import Header from "./Header";
import Footer from "./Footer";
import Home from './Home';
import About from './About';
import Login from './Login';
import Reg from './Reg';
import { useEffect, useState } from 'react';
import { LoginContext } from './LoginContext';
import Admin from './AdminPanel/Admin';
import Products from './AdminPanel/Products';
import ProductAdd from './AdminPanel/ProductAdd';
import ProductUpdate from './AdminPanel/ProductUpdate';
import ProductDelete from './AdminPanel/ProductDelete';
import Testimonial from './AdminPanel/Testimonial';
import Query from './AdminPanel/Query';
import BannerManagement from './AdminPanel/BannerManagement';
import BannerMngAdd from './AdminPanel/BannerMngAdd';
import BannerMngUpdate from './AdminPanel/BannerMngUpdate';
import BannerMngDelete from './AdminPanel/BannerMngDelete';
import BannerMoreDetails from './BannerMoreDetails';
import TestimonialForm from './TestimonialForm';
import TestiDelete from './AdminPanel/TestiDelete';
import TestiRoleUpdate from './AdminPanel/TestiRoleUpdate';
import UsersManagement from './AdminPanel/UsersManagement';
import UserStatus from './AdminPanel/UserStatus';
import AddressManagement from './AdminPanel/AddressManagement';
import AddressAdd from './AdminPanel/AddressAdd';
import AddressUpdate from './AdminPanel/AddressUpdate';
import ProductMoreDetail from './ProductMoreDetail';
import Cart from './Cart';


function App() {
  const [loginname, setLoginname] = useState(localStorage.getItem('loginname'))
  const [loginstatus, setLoginStatus] = useState(localStorage.getItem('loginstatus'))
  const[cart,setCart] = useState('')
  useEffect(()=>{
    localStorage.setItem('cart',JSON.stringify(cart))
  },[cart])

  return (
    
      <LoginContext.Provider value={{ loginname, setLoginname, loginstatus, setLoginStatus, cart, setCart }}>
        <Router>
          <Header />
          <Routes>
            {loginstatus ?
            <>
            <Route path='/' element={<Home />}></Route>
            <Route path='/about' element={<About />}></Route>            
            <Route path='/admin' element={<Admin />}></Route>
            <Route path='/banner' element={<BannerManagement />}></Route>
            <Route path='/bannermoredetail' element={<BannerMoreDetails />}></Route>
            <Route path='/bannermngadd' element={<BannerMngAdd />}></Route>
            <Route path='/bannermngupdate/:id' element={<BannerMngUpdate />}></Route>
            <Route path='/bannermngdelete/:id' element={<BannerMngDelete />}></Route>
            <Route path='/product' element={<Products />}></Route>
            <Route path='/productadd' element={<ProductAdd />}></Route>
            <Route path='/productupdate/:id' element={<ProductUpdate />}></Route>
            <Route path='/productdelete/:id' element={<ProductDelete />}></Route>
            <Route path='/testimonial' element={<Testimonial />}></Route>
            <Route path='/testiformshow' element={<TestimonialForm />}></Route>
            <Route path='/testidelete/:id' element={<TestiDelete />}></Route>
            <Route path='/testiroleupdate/:id' element={<TestiRoleUpdate />}></Route>
            <Route path='/query' element={<Query />}></Route>
            <Route path='/address' element={<AddressManagement />}></Route>
            <Route path='/addressadd' element={<AddressAdd />}></Route>
            <Route path='/addressupdate/:id' element={<AddressUpdate />}></Route>
            <Route path='/users' element={<UsersManagement />}></Route>
            <Route path='/userstatus/:id' element={<UserStatus />}></Route>
            <Route path='/productmoresetail/:id' element={<ProductMoreDetail />}></Route>
            <Route path='/cart' element={<Cart />}></Route>
            </>
            :
            <>
            <Route path='/' element={<Home />}></Route>
            <Route path='/login' element={<Login />}></Route>
            <Route path='/reg' element={<Reg />}></Route>           
            </>
            }
            
          </Routes>
          <Footer />
        </Router>
      </LoginContext.Provider>
    
  );
}

export default App