import { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import img from "./sliderimg.png"
import { LoginContext } from "./LoginContext";

function Productfetchhome() {
    const [product, setProduct] = useState([])
    const{cart, setCart} = useContext(LoginContext)
    useEffect(() => {
        fetch('/api/productcfetchhome').then((res) => { return res.json() }).then((data) => {
            //console.log(data)
            setProduct(data)
        })

    }, [])

    function handlecart(e,result){
        //console.log(result)
        let _cart = {...cart}
        if(!_cart.items){
            _cart.items = {}
        }
        if(!_cart.items[result._id]){
            _cart.items[result._id] = 1
        }else{
            _cart.items[result._id] +=1
        }
        if(!_cart.totalitems){
            _cart.totalitems = 1
        }else{
            _cart.totalitems +=1 
        }

        setCart(_cart)
        console.log(cart)
    }

    return (<>
        <h2 id="services-h2">Products</h2>
        <section id="services">

            {product.map((result) => (
                <div className="container pb-3" key={result._id}>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="card">
                                <img src={img} className="card-img-top img-fluid" alt="..." />
                                <div className="card-body">
                                    <h5 className="card-title"> {result.pname} </h5>
                                    <p className="card-text">{result.pdesc}</p>
                                    <p className="card-text"> Price : {result.pprice}</p> 
                                    <button className="btn btn-success me-2" onClick={(e)=>{handlecart(e,result)}}>Add Cart</button>
                                    <Link to={`/productmoresetail/${result._id}`}><button className="btn btn-primary">More Detail</button></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            ))}

        </section>
    </>

    );
}

export default Productfetchhome;