import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function BannerManagement(){
    const[banner,setBanner] = useState([])
    const[dataloading,setDataloading] = useState(true)

    useEffect(()=>{
        fetch('/api/bannermngfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloading(false)
            setBanner(data)
            
        })
    },[])
    

    return (
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9 mt-2">
                        <h2>Banner Management</h2>

                        <Link to='/bannermngadd'> <button className=" form-control btn btn-primary">Banner Add Here</button> </Link>

                        {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Banner Image</th>
                                    <th>Banner Name</th>
                                    <th>Banner Description</th>
                                    <th>Banner Long Description</th>
                                    <th>Action 1</th>
                                    <th>Action 2</th>

                                </tr>
                            </thead>
                            <tbody>
   
                                <tr>
                                    <td>{banner.bimage}</td>
                                    <td>{banner.bname}</td>
                                    <td>{banner.bdesc}</td>
                                    <td>{banner.blongdesc}</td>
                                    <td><Link to={`/bannermngupdate/${banner._id}`}><button className="form-control btn btn-success">Update</button></Link></td>
                                    <td><Link to={`/bannermngdelete/${banner._id}`}><button className="form-control btn btn-danger">Delete</button></Link></td>
                                </tr>
                        
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default BannerManagement;