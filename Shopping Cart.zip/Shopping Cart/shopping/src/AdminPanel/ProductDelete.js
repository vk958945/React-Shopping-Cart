import { useNavigate, useParams } from "react-router-dom";

function ProductDelete() {
    const{id} = useParams()
    const navigate = useNavigate()
    fetch(`/api/productdelete/${id}`,{
        method:'DELETE'
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==='Successfully Delete'){
            navigate('/product')
        }
    })
    return ( 
        <h2>Data Delete {id}</h2>
     );
}

export default ProductDelete;