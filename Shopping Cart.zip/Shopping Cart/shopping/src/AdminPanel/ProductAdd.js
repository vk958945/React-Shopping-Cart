import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Left from "./Left";

function ProductAdd() { 
    const[name,setName] = useState('')
    const[description,setDescription] = useState('')
    const[price,setPrice] = useState('')
    const navigate = useNavigate()
    function handleform(e){
        e.preventDefault()
        const formdata = {name,description,price}
        fetch('/api/productadd',{
            method:"POST",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                navigate('/product')
            }
        })
    }

    return ( 
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9 mt-2 text-success">
                        <h2 className="text-center m-2">Product Add Here</h2>
                    <form onSubmit={(e)=>{handleform(e)}}>

                        <label className="form-label fw-bold">Product Name</label>
                        <input type='text' className="form-control"
                        value={name} onChange={(e)=>{setName(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Product Description</label>
                        <input type='text' className="form-control"
                        value={description} onChange={(e)=>{setDescription(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Product Price</label>
                        <input type='number' className="form-control"
                        value={price} onChange={(e)=>{setPrice(e.target.value)}}
                        />

                        <button type='submit' className="form-control btn btn-success mt-2 mb-2 fw-bold">Add</button>
                    </form>
                    </div>
                </div>
            </div>
        </section>
     );
}

export default ProductAdd;