import { Link } from "react-router-dom";
import Left from "./Left";
import { useEffect, useState } from "react";

function AddressManagement(){
    const[address,setAddress] = useState([])
    const[dataloading,setDataloading] = useState(true)

    useEffect(()=>{
        fetch('/api/addressmngfetch').then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            setDataloading(false)
            setAddress(data)        
        })
    },[])
    

    return (
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left />
                    <div className="col-md-9 mt-2">
                        <h2>Address Management</h2>

                        <Link to='/addressadd'> <button className=" form-control btn btn-primary">Address Add Here</button> </Link>

                        {dataloading && <h2><img src="loader2.gif" alt="" style={{width:'200px', textAlign:'center'}}/></h2>}
                        <table className="table table-hover">
                            <thead>
                                <tr>
                                    <th>Address Name</th>
                                    <th>Mobile</th>
                                    <th>Phone</th>
                                    <th>Company Name</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Action 1</th>
                                    <th>Action 2</th>
                                </tr>
                            </thead>
                            <tbody>
   
                                <tr>
                                    <td>{address.caddress}</td>
                                    <td>{address.cmobile}</td>
                                    <td>{address.ctelephone}</td>
                                    <td>{address.cname}</td>
                                    <td>{address.cdesc}</td>
                                    <td>{address.cimage}</td>
                                    <td>{<Link to={`/addressupdate/${address._id}`}><button className="form-control btn btn-success">Update</button></Link>}</td>
                                    <td>{/*<Link to={`/addressmngdelete/`}><button className="form-control btn btn-danger">Delete</button></Link>*/}</td>
                                </tr>
                        
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    );
}

export default AddressManagement;