import Left from "./Left";

function Admin() {

    return ( 
      
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9 mt-2"><h2>Welcome to Admin Panel</h2></div>
                </div>
            </div>
        </section>
 
     );
}

export default Admin;