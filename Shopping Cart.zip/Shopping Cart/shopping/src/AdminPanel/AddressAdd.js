import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Left from "./Left";

function AddressAdd() { 
    const[address,setAddress] = useState('')
    const[mobile,setMobile] = useState('')
    const[telephone,setTelephone] = useState('')
    const[cname,setCname] = useState('')
    const[desc,setDesc] = useState('')
    const[image,setImage] = useState('')
    const navigate = useNavigate()
    function handleform(e){
        e.preventDefault()
        const formdata = {address,mobile,telephone,cname,desc,image}
        fetch('/api/addressadd',{
            method:"POST",
            headers:{"Content-type":"application/json"},
            body:JSON.stringify(formdata)
        }).then((res)=>{return res.json()}).then((data)=>{
            console.log(data)
            if(data._id){
                navigate('/address')
            }
        })
    }

    return ( 
        <section id="admin">
            <div className="container">
                <div className="row">
                    <Left/>
                    <div className="col-md-9 mt-2 text-success">
                        <h2 className="text-center m-2">Address & Company Add Here</h2>
                    <form onSubmit={(e)=>{handleform(e)}}>

                        <label className="form-label fw-bold">Company Address</label>
                        <input type='text' className="form-control"
                        value={address} onChange={(e)=>{setAddress(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Company Mobile Number</label>
                        <input type='number' className="form-control"
                        value={mobile} onChange={(e)=>{setMobile(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Company Telephone</label>
                        <input type='number' className="form-control"
                        value={telephone} onChange={(e)=>{setTelephone(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Company Name</label>
                        <input type='text' className="form-control"
                        value={cname} onChange={(e)=>{setCname(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Company Description</label>
                        <input type='text' className="form-control"
                        value={desc} onChange={(e)=>{setDesc(e.target.value)}}
                        />

                        <label className="form-label fw-bold">Company Image</label>
                        <input type='file' className="form-control"
                        value={image} onChange={(e)=>{setImage(e.target.value)}}
                        />

                        <button type='submit' className="form-control btn btn-success mt-2 mb-2 fw-bold">Add</button>
                    </form>
                    </div>
                </div>
            </div>
        </section>
     );
}

export default AddressAdd;