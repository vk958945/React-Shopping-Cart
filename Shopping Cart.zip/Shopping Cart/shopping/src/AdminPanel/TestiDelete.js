import { useNavigate, useParams } from "react-router-dom";

function TestiDelete() {
    const{id} = useParams()
    const navigate = useNavigate()

    fetch(`/api/testisinghdelete/${id}`,{
        method:'DELETE'
    }).then((res)=>{return res.json()}).then((data)=>{
        console.log(data)
        if(data.message==="Successfully Deleted"){
            navigate('/testimonial')
        }
    })

    return ( 
        <h2>Data Deleted {id}</h2>
     );
}

export default TestiDelete;