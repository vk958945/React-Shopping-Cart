const mongoose = require('mongoose')

const regSchema = mongoose.Schema({
    username:String,
    password:String,
    fullname:String,
    emailid:String,
    image:String,
    status:{type:String,default:'Active'},
    useridrole:{type:String,default:'Private'}
})

module.exports = mongoose.model('reg',regSchema)