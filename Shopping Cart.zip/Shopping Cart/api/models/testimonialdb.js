const mongoose = require('mongoose')

const testimonialSchema = mongoose.Schema({
    tname: String,
    tdesc:String,
    tcompanyname:String,
    tstatus:{type:String,default:'Private'}
    })

module.exports = mongoose.model('testimonial', testimonialSchema)