const mongoose = require('mongoose')

const bannerSchema = mongoose.Schema({
    bname:String,
    bdesc:String,
    blongdesc:String,
    bimage:String
})

module.exports = mongoose.model('banner',bannerSchema)