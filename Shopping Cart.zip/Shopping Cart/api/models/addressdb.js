const mongoose = require('mongoose')

const addressSchema = mongoose.Schema({
    caddress:String,
    cmobile:String,
    ctelephone:String,
    cname:String,
    cdesc:String,
    cimage:String
})

module.exports = mongoose.model('address',addressSchema)