const mongoose = require('mongoose')

const mongooseSchema = mongoose.Schema({
    pname: String,
    pdesc: String,
    pprice: Number,
    pstatus: { type: String, default: 'OUT STOCK' }
})

module.exports = mongoose.model('product', mongooseSchema)