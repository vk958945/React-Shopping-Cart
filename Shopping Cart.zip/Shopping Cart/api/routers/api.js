const router = require('express').Router()
const regc = require('../controllers/regcontroller')
const cproducts = require('../controllers/productaddcontroller')
const cbanner = require('../controllers/Bannercontroller')
const ctesti = require('../controllers/Testimonialcontroller')
const caddress = require('../controllers/addresscontroller')


router.post('/reg',regc.reginsert)
router.post('/login',regc.reglogin)

router.post('/productadd',cproducts.productadd)
router.get('/productfetch',cproducts.productfetch)
router.get('/productid/:id',cproducts.productid)
router.put('/productupdate/:id',cproducts.productupdate)
router.delete('/productdelete/:id',cproducts.productdelete)
router.get('/productcfetchhome',cproducts.productcfetchhome)
router.get('/singleproductfetch/:id',cproducts.singleproductfetch)
router.post('/allcartshow',cproducts.allcartshow)
router.delete('/productdelete/:id',cproducts.singleproductdelete)

router.post('/bannermngadd',cbanner.banneradd)
router.get('/bannermngfetch',cbanner.bannermngfetch)
router.get('/bannersinglefetch/:id',cbanner.bannersinglefetch)
router.put('/bannermngupdate/:id',cbanner.bannermngupdate)
router.delete('/bannermngdelete/:id',cbanner.bannermngdelete)
router.get('/bannerhomeshow',cbanner.bannerhomeshow)
router.get('/bannermoredetail',cbanner.bannermoredetail)

router.post('/tesimonialform',ctesti.tesimonialform)
router.get('/testimonialallfetch',ctesti.testimonialallfetch)
router.delete('/testisinghdelete/:id',ctesti.testisinghdelete)
router.put('/testiroleupdate/:id',ctesti.testiroleupdate)
router.get('/testiallfetches',ctesti.testiallfetches)

router.get('/usersfetch',regc.usersfetch)
router.put('/userstatus/:id',regc.userstatus)

router.post('/addressadd',caddress.addressadd)
router.get('/addressmngfetch',caddress.addressmngfetch)
router.get('/addresssinglefetch/:id',caddress.addresssinglefetch)
router.put('/addresssingupdate/:id',caddress.addresssingupdate)
router.get('/addressfetchhome',caddress.addressfetchhome)

module.exports = router