const express = require('express')
const app = express()
app.use(express.json())
require('dotenv').config()
const apirouter = require('../api/routers/api')
const mongoose = require('mongoose')
mongoose.connect(`${process.env.DB_URL}${process.env.DB_NAME}`,()=>{
    console.log(`Connected to DB ${process.env.DB_NAME}`)
})



app.use('/api',apirouter)
app.listen(process.env.PORT,()=>{
    console.log(`Server is running on Port ${process.env.PORT}`)
})